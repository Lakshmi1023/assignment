package com.te.largestkey;
import java.util.Map;
import java.util.Set;

public class UserMainCode {

	public static String getMaxKeyValue(Map<Integer,String> accept) {
		
		Object[] allKeys =  accept.keySet().toArray();
		
		return accept.get(allKeys[allKeys.length - 1] );
	}
}
