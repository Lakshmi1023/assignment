package com.te.largestkey;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
	
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Map<Integer,String> keypairs = new HashMap<>();
		
		int mapLength = scanner.nextInt();
		scanner.nextLine();
		
		for(int i=0;i<mapLength;i++) {

			int key = scanner.nextInt();
			scanner.nextLine(); // fixing int input memmory
			String value = scanner.nextLine();
			
			keypairs.put(key, value);

		}
		
	   	String maxKeyValue = UserMainCode.getMaxKeyValue(keypairs);
	   	
	   	System.out.println(maxKeyValue);
		
	}

}