package com.te.logicprogram;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the first num");
		int a=scanner.nextInt();
		System.out.println("enter the second num");
		int b=scanner.nextInt();
		System.out.println("enter the third num");
		int c=scanner.nextInt();
		int given=UserMainCode.getLuckySum(a,b,c);
		System.out.println("the lucky sum is:"+given);
	}

}
