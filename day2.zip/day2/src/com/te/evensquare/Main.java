package com.te.evensquare;
import java.util.Scanner;
public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the number");
	int given=scanner.nextInt();
	if(given<0)
		System.out.println("entered negative number");
	else
	{
		int res=UserMainCode.SumOfSquareOfEvenDigits(given);
		System.out.println("The sum of digits square:"+res);
	}
	
}
}
