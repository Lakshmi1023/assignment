package com.te.oddevenindex;

public class UserMainCode {
public static int sumOfOddEvenPositioned(int num) {
	int count=0;
	int last=0;
	int sum1=0;
	int sum2=0;
	int t1=num;
	int t2=num;
	//odd
	while(t1>0) {
		
		int r1=t1%10;//12345 r1=5// 1+3+5
		sum1=sum1+r1;//5+3+1 =9
		t1=t1/100;	//123//1
	
	}
	//even 2+4
	t2=t2/10;//1234
	while(t2>0) {
	
	int r2=t2%10;//4+2
		sum2=sum2+r2;//4+2=6
		t2=t2/100;//12
	
	}
	if(sum1==sum2) 
		return 1;
		else
			return -1;
	}

}


