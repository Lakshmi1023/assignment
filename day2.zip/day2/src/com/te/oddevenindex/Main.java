package com.te.oddevenindex;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the number");
	int res=scanner.nextInt();
	int res2=UserMainCode.sumOfOddEvenPositioned(res);
	if(res2==1)
		System.out.println("yes");
	else
		System.out.println("no");
}
}
