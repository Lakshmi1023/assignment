package com.te.BeanValidation2.service;

import java.util.List;

import com.te.BeanValidation2.dto.UserRequest;
import com.te.BeanValidation2.entity.Student;

public interface StudentService {
 public Student saveStudent(UserRequest userRequest);
 public List<Student>getAllStudent();
 public Student getStudent(Integer id);
 
}
