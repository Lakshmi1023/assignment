package com.te.BeanValidation2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.BeanValidation2.dao.StudentDao;
import com.te.BeanValidation2.dto.UserRequest;
import com.te.BeanValidation2.entity.Student;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao dao;

	@Override
	public Student saveStudent(UserRequest userRequest) {
		 Student student = new Student(0,userRequest.getName(),userRequest.getMarks(),userRequest.getAge());
		return dao.save(student);
	}

	@Override
	public List<Student> getAllStudent() {
		return dao.findAll();
	}

	@Override
	public Student getStudent(Integer id) {
		
		return dao.findById(id).get();
	}

}
