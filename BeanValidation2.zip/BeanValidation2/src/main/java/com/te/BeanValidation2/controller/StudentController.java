package com.te.BeanValidation2.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.BeanValidation2.dto.UserRequest;
import com.te.BeanValidation2.entity.Student;
import com.te.BeanValidation2.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService service;
	
	@PostMapping("/saveStudent")
	public ResponseEntity<Student>save(@RequestBody @Valid UserRequest userRequest) {
		Student saveStudent = service.saveStudent(userRequest);
		return new ResponseEntity<Student>(saveStudent,HttpStatus.OK);
		
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Student>>getAll(){
		List<Student> allStudent = service.getAllStudent();
		return new ResponseEntity<List<Student>>(allStudent,HttpStatus.OK);
		
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Student>getbyid(@PathVariable Integer id){
		Student student = service.getStudent(id);
		return new ResponseEntity<Student>(student,HttpStatus.OK);
		
	}
	
	
}
