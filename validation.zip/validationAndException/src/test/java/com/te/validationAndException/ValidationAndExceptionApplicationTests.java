package com.te.validationAndException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidationAndExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
