package com.te.sumsquare;

public class UserMainCode {
	public static int getSumOfSquareOfDigits(int num) {
		int last=0;
		int square=0;
		int sum=0;
		while(num>0) {
			last=num%10;
	     	square=last*last;
		    sum=sum+square;
			num=num/10;
			}
			
	
		return sum;
	}
	}
