package com.te.sumsquare;

import java.util.Scanner;
public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the number");
	int given=scanner.nextInt();
	if(given<0)
		System.out.println("enter positive number");
	else
	{
		int res=UserMainCode.getSumOfSquareOfDigits(given);
		System.out.println("The square of number:"+res);
	}
	
}
}