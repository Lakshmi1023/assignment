package com.te.digits;
import java.util.Scanner;
public class Main extends UserMaincode{
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the input");
		int n=scanner.nextInt();
		if(n<0)
			System.out.println("enter the valid input");
		
		else {
			System.out.println("occurence:"+countSeven(n));
			
		}
		scanner.close();
	}

}
