package com.te.reversenumber;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the number");
		int res=scanner.nextInt();
		int reverse=UserMainCode.reverseNumber(res);
		System.out.println("reverse number is:"+reverse);
				
		
	}
}
