package com.te.uniquenumber;

public class UserMainCode {
public static int checkUnique(int num) {
	int count=0;
	int r1;
	int r2;
	int num1;
	int num2;
	num1=num;
	num2=num;
	while(num1>0) {
		r1=num1%10;
		while(num>0) {
			r2=num2%10;
			if(r1==r2) {
				count++;
			}
			num2/=10;
		}
		num1/=10;
	}
	return count;
}

}
