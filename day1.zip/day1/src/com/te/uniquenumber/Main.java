package com.te.uniquenumber;
import java.util.Scanner;
public class Main {
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("enter the number");
		int num=scanner.nextInt();
		int result=UserMainCode.checkUnique(num);
		if(result==1)
			System.out.println("it is a unique number");
		else
			System.out.println("it is not a unique number");
	}

}
