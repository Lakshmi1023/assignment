package com.te.fibonacci;
import java.util.Scanner;
public class Main {
static Scanner scanner=new Scanner(System.in);
public static void main(String[] args) {
	System.out.println("enter the series");
	int res1=scanner.nextInt();
	int result=UserMainCode.getSumNfibos(res1);
	System.out.println();
	System.out.println("the sum of fibonacci series:"+result);
	
}
}
