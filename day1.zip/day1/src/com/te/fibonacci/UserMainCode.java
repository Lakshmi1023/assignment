package com.te.fibonacci;

public class UserMainCode {
public static int getSumNfibos(int num) {
	int n1=0;
	int n2=1;
	int sum=0;
	for(int i=1;i<num;i++) {
		int n3=n1+n2;
		System.out.println(n2);
		n1=n2;
		n2=n3;
		sum=sum+n1;
		
	}
	return sum;
	
	
}

}
