package com.te.odddigit;

public class Main {
	public static int checkSum(int gn) {
		
		int digits=0;
		int sum=0;
		for(int i=0;i<=gn;i++) {
			
			if(i%2!=0) {
				digits=i;
			}
			sum=sum+digits;
		}
		if(sum%2!=0)
			return 1;
		else
			return -1;
	}
}
