package com.te.odddigit;

import java.util.Scanner;

public class UserMainCode {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the number");
	int num=scanner.nextInt();
	if(num<0)
		System.out.println("enter the positive integer");
	else {
		int res=UserMainCode.checkSum(num);
		if(res==1)
			System.out.println("sum is odd");
		else
			System.out.println("sum is even");
		
	}
}

private static int checkSum(int num) {
	// TODO Auto-generated method stub
	return 0;
}
	
}