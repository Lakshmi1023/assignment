package com.te.palindrome;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the upper limit");
		int res=scanner.nextInt();
		System.out.println("enter the lower limit");
		int res2=scanner.nextInt();
		int palindrome=UserMainCode.addPalindrome(res,res2);
		System.out.println("sum of palindrome is:"+palindrome);
	}
	
	}
	



