package com.te.largestnum;

public class UserMainCode {
public static int checkLargestAmongCorner(int num[]) {
	int firstarray=num[0];
	int middlearray=num[num.length/2];
	int lastarray=num[num.length-1];
	
	System.out.println("first element:"+firstarray);
	System.out.println("middle element:"+middlearray);
	System.out.println("last element:"+lastarray);
	
	int large=firstarray>((middlearray>lastarray)?middlearray:lastarray)?firstarray
			:((middlearray>lastarray)?middlearray:lastarray);
	return large;
		
			
	
	
	
}
}
