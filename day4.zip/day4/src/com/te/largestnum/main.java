package com.te.largestnum;

import java.util.Scanner;

public class main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the size of a array");
	
	int size=scanner.nextInt();
	System.out.println("enter the array");
	int[] given=new int[size];
	for (int i = 0; i < given.length; i++) {
		given[i]=scanner.nextInt();
		
	}
	int res=UserMainCode.checkLargestAmongCorner(given);
	System.out.println(res);
}
}