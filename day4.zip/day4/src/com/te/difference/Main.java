package com.te.difference;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the array size");
	int size=scanner.nextInt();
	System.out.println("enter the array");
	int[] given=new int[size];
	for (int i = 0; i < given.length; i++) {
		given[i]=scanner.nextInt();
	}
	int res1=UserMainCode.getBigDiff(given);
	System.out.println(res1);
}
}
