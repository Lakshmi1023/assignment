package com.te.difference;

public class UserMainCode {
	public static int getBigDiff(int []a) {
		int larger=a[0];
		int smaller=a[0];
		int diff=0;
		for (int i = 0; i < a.length; i++) {
			if(larger<a[i]) {
				larger=a[i];
			}
		}
		for (int i = 0; i < a.length; i++) {
			if(smaller>a[i])
			smaller=a[i];
		}
		diff=larger-smaller;
		return diff;
	}
}
