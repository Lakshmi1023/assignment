package com.te.sumPower;

public class UserMainCode {
public static int getSumOfPower(int n,int[]a) {
	int sum=0;
	for (int i = 0; i < a.length; i++) {
		sum=sum+(int)(Math.pow(a[1], i));
	}
	return sum;
}
}
