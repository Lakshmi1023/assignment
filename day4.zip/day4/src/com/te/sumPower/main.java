package com.te.sumPower;

import java.util.Scanner;

public class main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the size");
	int size=scanner.nextInt();
	int[]array=new int[size];
	for (int i = 0; i < array.length; i++) {
		System.out.println("enter the element");
		array[i]=scanner.nextInt();
		int res=UserMainCode.getSumOfPower(i,array);
}
}
}
