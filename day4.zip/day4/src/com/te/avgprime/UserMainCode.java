package com.te.avgprime;

public class UserMainCode {
public static double averageElements(int array[] ) {
	int count=0;
	int count1=0;
	double avg=0;
	double sum=0;
	for(int i=0;i<array.length;i++) {
		count=0;
		for(int j=1;j<=i;j++) {
			if(i%j==0)
				count++;
		}
	
	if(count==2) {
		sum=sum+array[i];
		count1++;
	}
	}
	
	avg=sum/count1;
	return avg;
}
}
