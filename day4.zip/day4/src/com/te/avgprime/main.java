package com.te.avgprime;

import java.util.Scanner;

public class main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the size of a array");
	int size=scanner.nextInt();
    int array[]=new int[size];
    System.out.println("enter a array");
    for (int i = 0; i < array.length; i++) {
		array[i]=scanner.nextInt();
	}
    double res=UserMainCode.averageElements(array);
    System.out.println(res);
	
}
}
