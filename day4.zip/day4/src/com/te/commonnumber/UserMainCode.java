package com.te.commonnumber;

public class UserMainCode {
public static int sumCommonElements(int []firstarray,int []secondarray) {
	int sum=0;
	for (int i = 0; i < firstarray.length; i++) {
		for (int j = 0; j < secondarray.length; j++) {
			if(firstarray[i]==secondarray[j]) {
				sum=sum+firstarray[i];
			}
		}
	}
	return sum;
}

}
	