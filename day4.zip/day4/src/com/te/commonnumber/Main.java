package com.te.commonnumber;


import java.util.Scanner;
public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
    System.out.println("enter the size ");
    int size=scanner.nextInt();
    
    int firstarray[]=new int[size];
     System.out.println("enter the first array");
    for (int i=0;i<firstarray.length;i++) {
    firstarray[i]=scanner.nextInt();
    }
    
    int secondarray[]=new int[size];
    System.out.println("enter second array");
    for(int i=0;i<secondarray.length;i++) {
    	secondarray[i]=scanner.nextInt();
    }
    int result=UserMainCode.sumCommonElements(firstarray,secondarray);
    System.out.println(result);
    
    
    
    
    
    	
    	
		
	}
	
}
