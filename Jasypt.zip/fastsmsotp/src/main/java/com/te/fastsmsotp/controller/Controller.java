package com.te.fastsmsotp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.fastsmsotp.entity.SMS;
import com.te.fastsmsotp.service.SMSService;
@RestController
public class Controller {
	
	
	@Autowired
	private SMSService service;

//	@Value("${apiKey}")
//	private String apiKey;
	
	@PostMapping("/sms")
	ResponseEntity<?> sms(@RequestBody SMS sms) {
		SMS sms2 = service.sendSMS(sms);
		return new ResponseEntity<String>("Message sent successfully", HttpStatus.OK);
	}
	
	
}

