package com.te.fastsmsotp.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SMS {
	
	private String id;
	
	private String number;
	
	private String name;
	


}
