package com.te.fastsmsotp.service;

import java.net.URL;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import javax.net.ssl.HttpsURLConnection;

import org.springframework.stereotype.Service;

import com.te.fastsmsotp.entity.SMS;

@Service
public class SMSServiceImpl implements SMSService {

	@Override
	public SMS sendSMS(SMS sms) {
		
	try {
			//mvn jasypt:encrypt -Djasypt.encryptor.password=password 			
			String apiKey = "K6IMaNgwVf5IadHigtGxlS2DIURyq2hbUs2e0ZXgUWq2bT5HEt2d161pVpRs";
			String route = "otp";

			int variables_values = (int) (Math.random() * 9000) + 1000;
			
			System.out.println("Your OTP is " + variables_values + " Please do not share with anyone");

			String myUrl = "https://www.fast2sms.com/dev/bulkV2?authorization=" + apiKey + "&route=" + route
					 + "&numbers=" + sms.getNumber() + "&variables_values=" + variables_values  ;

			URL url = new URL(myUrl);

			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			

			int code = con.getResponseCode();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return sms;
	}
}
