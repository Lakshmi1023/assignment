package com.te.fastsmsotp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastsmsotpApplicationTests {

	@Test
	void contextLoads() {
	}

}
