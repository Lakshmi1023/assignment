package com.te.onetomany.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.onetomany.bean.Company;
import com.te.onetomany.service.CompanyService;

@RestController
public class CompanyController {

	@Autowired
	private CompanyService service;
	
	@PostMapping("/onetomanypro")
	public ResponseEntity<Company>reg(@RequestBody Company info){
		
		Company addCompany = service.addCompany(info);
		
		return new ResponseEntity<Company>(addCompany,HttpStatus.OK);
		
	}
}
