package com.te.onetomany.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.onetomany.bean.Company;
import com.te.onetomany.dao.CompanyDAO;

@Service
public class CompanyServiceImpl implements CompanyService{
  
	@Autowired
	private CompanyDAO dao;
	
	@Override
	public Company addCompany(Company info) {
		
		return dao.save(info);
	}

	@Override
	public Company findById(Company com, Integer id) {
		
		Company company = dao.findById(id).get();
		com.setCid(id);
		return company;
	}

}
