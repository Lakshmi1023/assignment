package com.te.onetomany.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.te.onetomany.bean.Employee;

@Repository
public interface EmployeeDAO extends JpaRepository<Employee, Integer> {

}
