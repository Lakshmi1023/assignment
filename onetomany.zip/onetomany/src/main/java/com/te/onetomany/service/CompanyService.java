package com.te.onetomany.service;

import com.te.onetomany.bean.Company;

public interface CompanyService {

	public Company addCompany(Company info);
	public Company findById(Company com,Integer id);
	
	
}
