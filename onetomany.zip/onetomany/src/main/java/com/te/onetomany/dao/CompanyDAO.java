package com.te.onetomany.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.te.onetomany.bean.Company;

@Repository
public interface CompanyDAO extends JpaRepository<Company, Integer> {

}
