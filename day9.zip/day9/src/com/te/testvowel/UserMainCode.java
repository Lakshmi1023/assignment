package com.te.testvowel;

public class UserMainCode {
public static String testVowels(String str) {
	String str1="aeiou";
	int count=0;
	
	
	for (int i = 0; i < str.length(); i++) {
		for (int j = 0; j < str1.length(); j++) {
			if(str.charAt(i)==str1.charAt(j)) {
				count++;
			}
			
		}
		
	}
	if(count>=5) {
		return "yes";
				
	}else
		return "no";
	
	
			
}
}
