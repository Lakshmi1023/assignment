package com.te.triplets;

public class UserMainCode {
	public static boolean checkTriplets(int a[]) {
		boolean res=false;
		for (int i = 0; i < a.length-2; i++) {
			if(a[i]==a[i+1])
					if(a[i+1]==a[i+2])
						res=true;
}
		return res;
	}
}
