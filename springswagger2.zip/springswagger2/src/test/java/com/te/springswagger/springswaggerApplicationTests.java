package com.te.springswagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class springswaggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
