package com.te.springswagger2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.springswagger2.bean.SpringSwaggerMovies;

@RestController
@RequestMapping("/api/movies")
public class SpringSwaggerMoviesController {
	private List<SpringSwaggerMovies> movies = new ArrayList<SpringSwaggerMovies>();// inmemory storage

	@GetMapping
	public List<SpringSwaggerMovies> getMovie() {// Movie is modelobj i want to create

		return movies;

	}

	@PostMapping
	public SpringSwaggerMovies addMovie(@RequestBody SpringSwaggerMovies movie) {
		movies.add(movie);
		return movie;

	}

}
