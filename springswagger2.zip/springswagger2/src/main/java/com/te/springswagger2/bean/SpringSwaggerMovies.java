package com.te.springswagger2.bean;

import lombok.Data;

@Data
public class SpringSwaggerMovies {

	private String name;
	private String actor;
}
