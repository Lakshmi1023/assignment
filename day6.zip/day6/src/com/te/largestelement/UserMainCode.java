package com.te.largestelement;

public class UserMainCode {
	public static int checkLargestAmongCorner(int[]a) {
		int first=a[0];
		int middle=a[a.length/2];
		int last=a[a.length-1];
		
		
		System.out.println("first element:"+first);
		System.out.println("middle element:"+middle);
		System.out.println("last element:"+last);
		
		int result=(first>((middle>last)?middle:last)?first:((middle>last)?middle:last));
		return result;
		
		
	}

}
