package com.te.largestelement;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the array size");
	int size=scanner.nextInt();
	if(size%2==0) {
		System.out.println("print odd number");
	}
	else {
		
		
	int a[]=new int[size];
	
	
	for (int i = 0; i < a.length; i++) {
		a[i]=scanner.nextInt();
		}
		
		int res=UserMainCode.checkLargestAmongCorner(a);
		System.out.println(res);
		
	}
}
	
}

