package com.te.MiddleElement;

public class UserMainCode {
public static int getMiddleElements(int a[]) {
	int middle=a[a.length/2];
	for (int i = 0; i < a.length; i++) {
		if(a[i]%2!=0) {
			System.out.println("Middle element is:"+middle);
			
		}
	}
	return middle;
}
}
