package com.te.MiddleElement;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the array");
	int size=scanner.nextInt();
	int a[]=new int[size];
	for (int i = 0; i < a.length; i++) {
		a[i]=scanner.nextInt();
	}
	
	int res=UserMainCode.getMiddleElements(a);
	System.out.println(res);
}
}

