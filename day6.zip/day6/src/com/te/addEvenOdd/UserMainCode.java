package com.te.addEvenOdd;

public class UserMainCode {
public static int addEvenOdd(int a[]) {
	int even=0;
	
	int odd=0;
	int sum=0;
	
	for (int i = 0; i < a.length; i++) {
	
	if(a[i]%2==1) {
		odd=a[i]*a[i]*a[i];
		sum=sum+odd;
		
	}
	else {
		even=a[i]*a[i];
	sum=sum+even;
	
	}
}
	return sum;	
	
}
}
	
		
	
	
	


