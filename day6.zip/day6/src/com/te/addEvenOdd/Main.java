package com.te.addEvenOdd;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the size");
	int size=scanner.nextInt();
	int a[]=new int[size];
	for (int i = 0; i < a.length; i++) {
		a[i]=scanner.nextInt();
	}
	int result=UserMainCode.addEvenOdd(a);
	System.out.println(result);
	
}
}
