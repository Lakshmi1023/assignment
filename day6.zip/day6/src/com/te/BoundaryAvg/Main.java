package com.te.BoundaryAvg;

import java.util.Scanner;
 
public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the array and size");
	int size=scanner.nextInt();
	int a[]=new int[size];
	
	for (int i = 0; i < a.length; i++) {
		a[i]=scanner.nextInt();
	}
	float result=UserMainCode.getBoundaryAverage(a);
	System.out.println(result);
}
}
