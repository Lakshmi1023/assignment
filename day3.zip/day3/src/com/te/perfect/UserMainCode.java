package com.te.perfect;

public class UserMainCode {
public static boolean getPerfection(int num) {
	int sum=0;
	
	for(int i=1;i<num;i++) {
		if(num%i==0) {
			sum=sum+i;
		}
	}
	if(sum==num) {
		
		System.out.println("perfect");
		return true;
		
	}
		else {
			System.out.println("not perfect");
			return false;
			
		
	}
	
	
}
}
