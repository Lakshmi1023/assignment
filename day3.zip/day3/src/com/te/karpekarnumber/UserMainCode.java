package com.te.karpekarnumber;

public class UserMainCode {
public static int getKaprekarNumber(int n) {
	int count=0;
	int q=0;
	int r=0;
	int n1=n;
	int sq=n*n;
	while(n1>0) {
		count++;
		n1=n1/10;
	}
	r=sq%(int) Math.pow(10,count);
	q=sq/(int) Math.pow(10,count);
	if(r+q==n) {
		System.out.println("karpekar number");
		return 1;
	}
	else {
		System.out.println("not a karpekar number");
		return -1;
	}
}  
}
