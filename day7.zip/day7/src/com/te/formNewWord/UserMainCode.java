package com.te.formNewWord;

public class UserMainCode {
	static String formNewWord(String str, int num) {

		String res = "";
		String first = str.substring(0, num);
		String last = str.substring(str.length() - num);
		
		res = first + last;

		return res;
	}
}
