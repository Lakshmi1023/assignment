package com.te.formNewWord;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the string and number");
	String str=scanner.next();
	int num = scanner.nextInt();

	System.out.println(UserMainCode.formNewWord(str, num));
}
}
