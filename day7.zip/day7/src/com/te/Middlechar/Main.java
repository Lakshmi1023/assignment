package com.te.Middlechar;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the string");
	String str=scanner.nextLine();
	if(str.length()%2!=0) {
		System.out.println("enter even number");
		}
	else
		System.out.println();
	String str1=UserMainCode.getMiddleChar(str);
	System.out.println(str1);
	
	
	
}
}
