package com.te.Middlechar;

public class UserMainCode {
public static String getMiddleChar(String str){
	StringBuffer stringbuffer=new StringBuffer();
		
		System.out.println(str.charAt(str.length()/2-1));
		System.out.println(str.charAt(str.length()/2));
		return "";
		
}
}
