package com.te.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


//for filter the salary of employee where emp salary is greater than 20
public class Main {
	public static void main(String[] args) {
		List<Employee>list=new ArrayList<Employee>();
		//without stream
		
	
//		for (Employee employee : getDetails()) {
//			if(employee.getSalary()>21000) {
//				list.add(employee);
//			}
//		}
//		for (Employee employee : list) {
//			System.out.println(employee);
//		}
//		
//		System.out.println("*************************");
		//using stream api
//		List<Employee> list2=getDetails()
//				.stream().filter((employee)->employee.getSalary()>20000)
//				.collect(Collectors.toList());
//		list2.forEach(System.out::println);
		
		//we can use like this also
		//stream api
		             getDetails().stream().filter((employee)
		         ->employee.getSalary()>20000).forEach(System.out::println);
	}
	

	private static List<Employee> getDetails() {

		List<Employee> details = new ArrayList<Employee>();
		details.add(new Employee(11, "aaa", 23000));
		details.add(new Employee(11, "aaa", 22000));
		details.add(new Employee(11, "aaa", 20000));
         return details;
 }
}

