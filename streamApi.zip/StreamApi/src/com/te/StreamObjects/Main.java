package com.te.StreamObjects;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class Main {
	public static void main(String[] args) {
		// create stream
		Stream<Integer> stream = Stream.of(1, 2, 3);
		stream.forEach(System.out::println);

		// create stream from sources
		// using collection
		Collection<String> collection = Arrays.asList("aaa", "bbbb", "ccc");
		Stream<String> stream2 = collection.stream();
		stream2.forEach(System.out::println);
		
		// using list
		List<String> list = Arrays.asList("aaa", "bbbb", "ccc");
		Stream<String> stream3 = list.stream();
		stream3.forEach(System.out::println);
		
		// using set
		Set<String> set = new HashSet<String>(list);
		Stream<String> stream4 = set.stream();
		stream4.forEach(System.out::println);
		
		// using array
		Integer[] array = { 1, 2, 3, 3 };
		Stream<Integer> stream5 = Arrays.stream(array);
		stream5.forEach(System.out::println);

	}
}
