package com.te.bootlms3.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.bootlms3.Service.EmployeeService;
import com.te.bootlms3.bean.Employee;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	
	@PostMapping("/add")
	public ResponseEntity<Employee>reg(@RequestBody @Valid Employee details){
		Employee employee = service.addEmployee(details);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
		
	}

	@GetMapping("/getId/{id}")
	public ResponseEntity<?>regs(@PathVariable Integer id){
		Employee getbyId = service.getbyId(id);
		return new ResponseEntity<Employee>(getbyId,HttpStatus.OK);
	}/./.
	
	@GetMapping("/get/{name}")
	public ResponseEntity<?>name(@PathVariable String name){
		List<Employee> byName = service.findByName(name);
		return new ResponseEntity<List<Employee>>(byName,HttpStatus.OK);
	}
	
	@GetMapping("/query")
	public ResponseEntity<?>query(){
		List<Employee> query = service.findByName();
		return new ResponseEntity<List<Employee>>(query,HttpStatus.OK);
		
	}
	
	@GetMapping("/desc")
	public ResponseEntity<?>desc(){
		List<Employee> nameDesc = service.findByOrderByNameDesc();
		return new ResponseEntity<List<Employee>>(nameDesc,HttpStatus.OK);
	}
	
	@PostMapping("/del/{id}")
	public ResponseEntity<?>del(@PathVariable Integer id){
		Employee deletebyid = service.deletebyid(id);
		return new ResponseEntity<String>("deleted",HttpStatus.OK);
	}
	
	
}
