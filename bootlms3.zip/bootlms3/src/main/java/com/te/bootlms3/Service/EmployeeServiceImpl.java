package com.te.bootlms3.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.te.bootlms3.bean.Employee;
import com.te.bootlms3.dao.EmployeeDAO;

@Service
public class EmployeeServiceImpl implements EmployeeService{
@Autowired
	private EmployeeDAO dao;

	@Override
	public Employee addEmployee(Employee details) {
		return dao.save(details);
		
	}
	
	@Override
	@Cacheable(cacheNames = "employee" , key="#id")
	public Employee getbyId(Integer id) {
		
		return dao.findById(id).get();
	}
	@Override
	public List<Employee> findByName(String name) {
		
		return dao.findByName(name);
	}
	@Override
	public List<Employee> findByName() {
		return dao.findByName();
	}
	@Override
	public List<Employee> findByOrderByNameDesc() {
		
		return dao.findByOrderByNameDesc();
	}
	@Override
	@CacheEvict(cacheNames = "employee",key = "#id")
	public Employee deletebyid(Integer id) {
		dao.deleteById(id);
		return null;
	} 

}
