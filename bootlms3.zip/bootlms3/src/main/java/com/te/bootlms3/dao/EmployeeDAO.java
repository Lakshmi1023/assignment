package com.te.bootlms3.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.te.bootlms3.bean.Employee;

@Repository
public interface EmployeeDAO extends CrudRepository<Employee, Integer> {

	public List<Employee> findByName(String name);
	@Query("from Employee where name like 'p%' ")
	public List<Employee> findByName();
	
	public List<Employee> findByOrderByNameDesc();
}
