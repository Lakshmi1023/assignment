package com.te.bootlms3.Service;

import java.util.List;

import com.te.bootlms3.bean.Employee;

public interface EmployeeService {
	
 public Employee addEmployee(Employee details);
 
 public Employee getbyId(Integer id);
 public List<Employee> findByName(String name);
 public List<Employee> findByName();
 public List<Employee> findByOrderByNameDesc();
 public Employee deletebyid(Integer id);


}
