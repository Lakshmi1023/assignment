package com.te.bootlms3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class Bootlms3Application {

	public static void main(String[] args) {
		SpringApplication.run(Bootlms3Application.class, args);
	}

}
