package arrayListSub;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	ArrayList<Integer> list1 = new ArrayList<Integer>();
	ArrayList<Integer> list2 = new ArrayList<Integer>();
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the size of first arraylist");
	int size1=scanner.nextInt();
	
	System.out.println("enter the first arraylist");
	for (int i = 0; i < size1; i++) {
		list1.add(scanner.nextInt());
	}
	System.out.println("enter the size of second arraylist");
	int size2=scanner.nextInt();
	System.out.println("enter the second arraylist");
	for (int i = 0; i < size2; i++) {
		list2.add(scanner.nextInt());
	}
	int num[]=UserMainCode.arrayListSubtractor(list1,list2);
	
	Arrays.sort(num);
	for (int i : num) {
		System.out.println(i);
	}
	
}

}
