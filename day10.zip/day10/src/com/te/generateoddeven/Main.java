package com.te.generateoddeven;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	ArrayList<Integer>list1=new ArrayList<Integer>();
	ArrayList<Integer>list2=new ArrayList<Integer>();
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the first array size");
	int size1=scanner.nextInt();
	for (int i = 0; i < size1; i++) {
		list1.add(scanner.nextInt());
	}
	
	System.out.println("enter the size of second array");
	
	for (int i = 0; i < size1; i++) {
		list2.add(scanner.nextInt());
	}
	System.out.println(UserMainCode.generateOddEvenList(list1, list2, size1));
}
}
