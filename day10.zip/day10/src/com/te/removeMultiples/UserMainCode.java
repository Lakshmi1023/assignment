package com.te.removeMultiples;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class UserMainCode {
public static ArrayList<Integer> removeMultiplesOfThree(ArrayList list1,int size){
	//ArrayList<Integer>list=new ArrayList<Integer>();
	
	for (int j = 2; j < list1.size(); j+=2) {
            
			list1.remove(j);
			
	}
		return list1;
	}
}

