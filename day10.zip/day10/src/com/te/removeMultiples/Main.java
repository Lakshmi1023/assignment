package com.te.removeMultiples;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	ArrayList<Integer> list1 = new ArrayList<Integer>();
	System.out.println("enter the size");
	int size=scanner.nextInt();
	System.out.println("enter the value");
	for (int i = 0; i < size; i++) {
		list1.add(scanner.nextInt());
	}
	System.out.println(UserMainCode.removeMultiplesOfThree(list1, size));
}
}
