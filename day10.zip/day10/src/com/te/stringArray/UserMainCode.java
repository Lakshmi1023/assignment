package com.te.stringArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class UserMainCode {
	public static String[] convertToStringArray(ArrayList list,int size){
	for (int i = 0; i < size; i++) {
		Collections.sort(list);
	}
	
	String arr1[] = new String[list.size()];
	list.toArray(arr1);
	for (int i = 0; i < size; i++) {
		System.out.println(arr1[i]);
	}
	return arr1;
}
}
