package com.te.stringArray;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	ArrayList<String>list=new ArrayList<String>();
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the size");
	int size=scanner.nextInt();
	System.out.println("enter the value");
	for (int i = 0; i < size; i++) {
		list.add(scanner.next());
	}
	UserMainCode.convertToStringArray(list, size);
}
}
