package com.te.sortMergedArrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	List<Integer> arrayList = new ArrayList();
	List<Integer>arrayList2=new ArrayList();
	int size=5;
	System.out.println("enter the first ArrayList");
	for (int i = 0; i < size; i++) {
	   arrayList.add(scanner.nextInt());
	}
	System.out.println("enter the second ArrayList");
	for (int i = 0; i < size; i++) {
		arrayList2.add(scanner.nextInt());
	}
	
	System.out.println(UserMainCode.sortMergedArrayList(arrayList,arrayList2));

	
	
	
}
}
