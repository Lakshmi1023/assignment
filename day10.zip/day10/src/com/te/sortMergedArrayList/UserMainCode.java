package com.te.sortMergedArrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UserMainCode {
public static ArrayList<Integer> sortMergedArrayList(List arrayList,List arrayList2) {
	ArrayList<Integer>list=new ArrayList<Integer>();
	arrayList.addAll(arrayList2);
		System.out.println("After merging"+arrayList);
		Collections.sort(arrayList);
		System.out.println("after sorting:"+arrayList);
		Integer element2=(Integer) arrayList.get(2);
		Integer element6=(Integer) arrayList.get(6);
		Integer element8=(Integer) arrayList.get(8);
		
		list.add(element2);
		list.add(element6);
		list.add(element8);
		 return list;
	
}
}
