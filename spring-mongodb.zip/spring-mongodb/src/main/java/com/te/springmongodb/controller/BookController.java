package com.te.springmongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.service.BookService;
import com.te.springmongodb.entity.Book;
import com.te.springmongodb.repository.BookRepository;

@RestController
public class BookController {
	@Autowired
	private BookService service;
	
	@PostMapping("/saveBook")
	public ResponseEntity<Book>save(@RequestBody Book book){
		Book saveBook = service.saveBook(book);
		return new ResponseEntity<Book>(saveBook,HttpStatus.OK);
		
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<Book>get(@PathVariable Integer id){
		Book byId = service.getById(id);
		return new ResponseEntity<Book>(byId,HttpStatus.OK);
		}
	 
	@GetMapping("/findAll")
	public ResponseEntity<List<Book>> findAll(){
		List<Book> findAll = service.findAll();
		return new ResponseEntity<List<Book>>(findAll,HttpStatus.OK);
		
	}
	@PostMapping("/del/{id}")
	public ResponseEntity<String> delete(@PathVariable Integer id){
		 service.deleteBook(id);
		return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
		}	
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Book>update(@RequestBody Book book,@PathVariable Integer id){
		Book updateBook = service.updateBook(book, id);
		return new ResponseEntity<Book>(updateBook,HttpStatus.OK);
		}	
	
	
}
