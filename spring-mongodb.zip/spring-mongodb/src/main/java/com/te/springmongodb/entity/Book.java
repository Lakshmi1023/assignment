package com.te.springmongodb.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Document(collection = "Book")
@AllArgsConstructor
@NoArgsConstructor
public class Book {
	@Id
	private Integer id;
	private String bookName;
	private String authorName;
	
	private List<Student>list;
}
