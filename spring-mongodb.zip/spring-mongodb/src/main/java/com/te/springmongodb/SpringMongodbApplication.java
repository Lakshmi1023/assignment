package com.te.springmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.te.springmongodb.repository.BookRepository;

@SpringBootApplication(scanBasePackages = "com.te")
//@EnableMongoRepositories(basePackageClasses = BookRepository.class)
public class SpringMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMongodbApplication.class, args);
	}

}
