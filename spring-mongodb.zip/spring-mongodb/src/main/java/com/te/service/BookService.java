package com.te.service;

import java.util.List;

import com.te.springmongodb.entity.Book;

public interface BookService {

	public Book saveBook(Book book);

	public Book getById(Integer id);

	public List<Book> findAll();
	public Book deleteBook(Integer id);
	
	public Book updateBook(Book book,Integer id);

}
