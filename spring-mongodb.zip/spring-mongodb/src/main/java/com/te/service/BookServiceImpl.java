package com.te.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.springmongodb.entity.Book;
import com.te.springmongodb.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepository repository;

	@Override
	public Book saveBook(Book book) {
		// TODO Auto-generated method stub
		return repository.save(book);
	}

	@Override
	public Book getById(Integer id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public List<Book> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Book deleteBook(Integer id) {
		repository.deleteById(id);
		return null;
	}

	@Override
	public Book updateBook(Book book,Integer id) {
		Book books = repository.findById(id).get();
		books.setBookName(book.getBookName());
		return repository.save(books);
	}
	
	

}
