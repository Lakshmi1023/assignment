package com.te.springmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
