package com.te.fastsmsotp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication

@EnableEncryptableProperties
public class FastsmsotpApplication {

	public static void main(String[] args) {
		SpringApplication.run(FastsmsotpApplication.class, args);
		
	
	
	}
	
	
	
	

}
