package com.te.fastsmsotp.service;

import com.te.fastsmsotp.entity.SMS;

public interface SMSService {

	public SMS sendSMS(SMS sms);
}
