package com.te.pagingandsorting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagingandsortingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagingandsortingApplication.class, args);
	}

}
