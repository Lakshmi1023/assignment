package getSubstring;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter first string");
	String str=scanner.next();
	System.out.println("enter second string");
	String str2=scanner.next();
	
	System.out.println(UserMainCode.getSubstring(str, str2));
}
}
