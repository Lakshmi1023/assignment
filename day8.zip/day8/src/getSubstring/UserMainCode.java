package getSubstring;

public class UserMainCode {
public static int getSubstring(String str,String str2) {
	int count=0;
	int length=str2.length();
	for (int i = 0; i < str2.length()-2; i++) {//catcowcat
		String str3=str.substring(i,i+length); //cat+catcowcat
		//System.out.println(str3);
		if(str3.equals(str2))
			count++;
		}
	return count;
}
}
