package com.te.repeatfront;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	
	System.out.println("enter a string");
	String str1=scanner.next();
	
	System.out.println("enter a number");
	int res=scanner.nextInt();
	
	System.out.println(UserMainCode.repeatFirstThreeCharacters(str1, res));
}
}
