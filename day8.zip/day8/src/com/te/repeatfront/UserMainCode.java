package com.te.repeatfront;

public class UserMainCode {
public static String repeatFirstThreeCharacters(String str,int n) {
	
	String str3="";
	if(str.length()<3) //so
		for (int i = 0; i < n; i++) {
			str3=str3+str;
			}
	else
		
	for (int i = 0; i < n; i++) {//cowcat
		String sub=str.substring(0,3);
		str3=str3+sub;
		
		}
	
	return str3;
}
}
