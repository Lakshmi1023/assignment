package com.te.reshape;

import java.util.Iterator;

public class UserMainCode {
public static String reShape(String str) {
	String str2="";
	
	for (int i = str.length()-1;i>=0;i--) {
		str2=str2+str.charAt(i)+"-";
	}
	return str2;
		
	}
}