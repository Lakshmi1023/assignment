package com.te.reshape;

import java.util.Scanner;
public class Main {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter a string");
	String res=scanner.next();
	System.out.println(UserMainCode.reShape(res));
	
}	
}
