package com.te.springmongoautoincrement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmongoautoincrementApplicationTests {

	@Test
	void contextLoads() {
	}

}
