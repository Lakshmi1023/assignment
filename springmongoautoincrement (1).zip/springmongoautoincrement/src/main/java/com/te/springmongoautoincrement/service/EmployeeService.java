package com.te.springmongoautoincrement.service;

import com.te.springmongoautoincrement.entity.Employee;

public interface EmployeeService {
	
	Employee save(Employee employee);
	

}
