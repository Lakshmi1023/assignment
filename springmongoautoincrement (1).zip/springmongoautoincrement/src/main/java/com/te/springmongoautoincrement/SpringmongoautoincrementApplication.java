package com.te.springmongoautoincrement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmongoautoincrementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmongoautoincrementApplication.class, args);
	}

}
