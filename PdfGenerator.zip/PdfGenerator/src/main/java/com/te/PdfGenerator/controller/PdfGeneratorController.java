package com.te.PdfGenerator.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lowagie.text.DocumentException;
import com.te.PdfGenerator.service.PdfGeneratorService;

@RestController
public class PdfGeneratorController {
@Autowired
	private PdfGeneratorService service;
	
@GetMapping("/pdf/generate")
public void generatePdf(HttpServletResponse response) throws DocumentException, IOException {
	response.setContentType("application/pdf");
	DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd:hh:mm:ss");
	String currentDateTime=dateFormat.format(new Date());
	String headerKey="content-Disposition";
	String headerValue="attachment; filename=pdf_"+currentDateTime +".pdf";
	response.setHeader(headerKey, headerValue);
	service.export(response);
	
	
}
}
