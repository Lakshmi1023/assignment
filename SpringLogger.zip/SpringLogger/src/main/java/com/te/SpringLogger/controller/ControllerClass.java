package com.te.SpringLogger.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerClass {

	Logger logger=LoggerFactory.getLogger(ControllerClass.class);
	@RequestMapping("/hello")
	public String hello() {
		
		logger.debug("hello to DEBUG level");
		return "hello";
		
	}
}
