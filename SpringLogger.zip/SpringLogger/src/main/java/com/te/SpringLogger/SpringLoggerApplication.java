package com.te.SpringLogger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLoggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringLoggerApplication.class, args);
	}

}
