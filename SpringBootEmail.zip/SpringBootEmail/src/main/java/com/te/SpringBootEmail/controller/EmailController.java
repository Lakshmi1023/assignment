package com.te.SpringBootEmail.controller;

import javax.mail.MessagingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.te.SpringBootEmail.bean.EmailDetails;
import com.te.SpringBootEmail.service.EmailService;

import ch.qos.logback.classic.joran.action.LoggerAction;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EmailController {
	Logger logger=LoggerFactory.getLogger(EmailController.class);

	@Autowired
	private EmailService service;
	//sending simple mail
	
	@PostMapping("/sendmail")
	public String sendMail(@RequestBody EmailDetails details) {
		log.debug("errormsg");
		
		String simpleMail = service.sendSimpleMail(details);
		return simpleMail;
		
	}
	
	//sending mail attachment
	@PostMapping("/sendmailwithattachment")
	public String sendMailWithAttachment(@RequestBody EmailDetails details)  {
		
		String mailWithAttachment = service.sendMailWithAttachment(details);
		return mailWithAttachment;
		
	}
	
}
