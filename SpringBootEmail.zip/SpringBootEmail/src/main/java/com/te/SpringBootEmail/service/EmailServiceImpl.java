package com.te.SpringBootEmail.service;

import java.io.File;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.te.SpringBootEmail.bean.EmailDetails;


@Service
public class EmailServiceImpl implements EmailService{

	@Autowired
    private JavaMailSender javaMailSender;
	@Value("${spring.mail.username}")
	private String sender;
	
	@Override
	public String sendSimpleMail(EmailDetails details) {
		//try {
			//creating simple mail message
			SimpleMailMessage mailMessage=new SimpleMailMessage();
			//set necessary details
			mailMessage.setFrom(sender);
			mailMessage.setTo(details.getRecipient());
			mailMessage.setText(details.getMsgBody());
			mailMessage.setSubject(details.getSubject());
			
			//sending the mail
			//mailMessage.setText("Mail sent");
			javaMailSender.send(mailMessage);
			return "Mail send successfully";
		//}
		//catch (Exception e) {
			//return "Error while Sending Mail";
		//}
		
	}
	// Method 2
    // To send an email with attachment
	@Override
	public String sendMailWithAttachment(EmailDetails details)  {
		//creating mime message
		MimeMessage mimeMessage=javaMailSender.createMimeMessage();
		
		System.out.println("mail with attachment");
		MimeMessageHelper mimemessageHelper;
		try {
			 //Setting multipart as true for attachments to
            // be send
			mimemessageHelper=new MimeMessageHelper(mimeMessage,true);
			 mimemessageHelper.setFrom(sender);
			 System.out.println("sender:"+sender);
	            mimemessageHelper.setTo(details.getRecipient());
	            mimemessageHelper.setText(details.getMsgBody());
	            mimemessageHelper.setSubject( details.getSubject());
	            
	            //adding the attachment
	            System.out.println("Adding attachment");
	            System.out.println(details.getAttachment());
	            FileSystemResource file=new FileSystemResource(new File(details.getAttachment()));
	            mimemessageHelper.addAttachment(file.getFilename(), file);
	            //sending the mail
	            javaMailSender.send(mimeMessage);
	            System.out.println("sending mail");
	            return "Mail sent successfully";
		}
		catch (MessagingException e) {

            System.out.println(e);
            return "Error while sending mail!!!";
		}
		
	}

}
