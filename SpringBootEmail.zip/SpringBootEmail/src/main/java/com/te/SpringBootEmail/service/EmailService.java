package com.te.SpringBootEmail.service;

import com.te.SpringBootEmail.bean.EmailDetails;

public interface EmailService {

	String sendSimpleMail(EmailDetails details);
	
	String sendMailWithAttachment(EmailDetails details);
}
