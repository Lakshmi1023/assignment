package com.te.mailsender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailusingbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
