package com.te.redis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
@EnableRedisRepositories
public class RedisConfig {

    @Bean
    //first step is use jedisconnection factory
    //public class JedisConnectionFactory
    //extends Object
    //implements InitializingBean, DisposableBean, RedisConnectionFactory
    //JedisConnectionFactory should be configured using an environmental configuration and the client configuration
    public JedisConnectionFactory connectionFactory() {  // jedisconnection factory is a class
    	
        RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration();
        configuration.setHostName("localhost"); //we have to jedis what is host and port
        configuration.setPort(6379);//these configuration obj we need to pass to this jedisconnection so,
        //config obj we need to pass jcf
        return new JedisConnectionFactory(configuration);
    }
    
    //I want to access redis server from our app we need some template

    @Bean
    public RedisTemplate<String, Object> template() {
    	//string as key and value as obj
    	//create obj for template
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        //for this template we need to add conn factory
        template.setConnectionFactory(connectionFactory());
        template.setKeySerializer(new StringRedisSerializer()); // key asa string
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new JdkSerializationRedisSerializer());
        template.setValueSerializer(new JdkSerializationRedisSerializer());
        template.setEnableTransactionSupport(true);
        template.afterPropertiesSet(); // set all the property
        return template;
    }

}
